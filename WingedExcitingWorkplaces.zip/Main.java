import java.util.Scanner;

class Main {
  public static void main(String[] args){
    Scanner readme = new Scanner(System.in);
    System.out.println("Enter Two Numbers (Press Enter after each, no decimals):");
   //two variables to hold numbers
   int n1, n2, n3, n4;
   n1 = readme.nextInt();
   n2 = readme.nextInt();
   n3 = 1;
   n4 = (n1 > n2) ? n1 : n2;
   for(int i = 1; i <= n1 && i <= n2; i++)
        {
            if(n1%i==0 && n2%i==0)
                n3 = i;
                
        }

        System.out.printf("GCF of %d and %d is: %d", n1, n2, n3);
   System.out.println("");
   while(true){
      if(n4 % n1 == 0 && n4 % n2 == 0){
        System.out.printf("The LCM of %d and %d is: %d", n1, n2, n4);
      break;
        }else{
          ++n4;
        }
    }
   
  } 
  

}